# demo-crm (Email → LLM → HubSpot)

Single-inbox demo:
- Poll Gmail via IMAP
- Extract text (email + attachments)
- LLM → JSON
- Validate/repair (Pydantic)
- Sync to HubSpot

## Quickstart
```bash
pip install -r requirements.txt
cp .env.example .env   # fill values
python app.py

---

### 0.7 Sanity check
In VS Code terminal, run:
```bash
python - <<'PY'
import requests, imapclient, pydantic, pypdf, docx, openpyxl
print("✅ Imports OK")
PY
