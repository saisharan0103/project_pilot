import os, requests, imapclient, json, time
from dotenv import load_dotenv

load_dotenv()

def test_imap():
    try:
        srv = imapclient.IMAPClient(os.getenv("IMAP_HOST"), ssl=True)
        srv.login(os.getenv("IMAP_EMAIL"), os.getenv("IMAP_PASSWORD"))
        srv.select_folder(os.getenv("INBOX_LABEL", "INBOX"))
        srv.logout()
        print("✅ IMAP OK")
    except Exception as e:
        print("❌ IMAP FAILED:", e)

def test_hubspot():
    try:
        token = os.getenv("HUBSPOT_PRIVATE_TOKEN")
        url = "https://api.hubapi.com/crm/v3/objects/contacts?limit=1"
        r = requests.get(url, headers={"Authorization": f"Bearer {token}"})
        if r.status_code == 200:
            print("✅ HubSpot OK")
        else:
            print(f"❌ HubSpot FAILED {r.status_code}: {r.text[:200]}")
    except Exception as e:
        print("❌ HubSpot FAILED:", e)

def test_gemini():
    try:
        key = os.getenv("GEMINI_API_KEY")
        ep = os.getenv("GEMINI_ENDPOINT")
        body = {
            "contents":[{"role":"user","parts":[{"text":"Return JSON: {\"ping\":\"pong\"}"}]}],
            "generationConfig":{"response_mime_type":"application/json"}
        }
        t0 = time.time()
        r = requests.post(f"{ep}?key={key}", json=body, headers={"Content-Type":"application/json"})
        dt = int((time.time()-t0)*1000)
        if r.status_code == 200:
            data = r.json()
            print(f"✅ Gemini OK ({dt} ms) →", json.dumps(data.get("candidates",[{}])[0], indent=2)[:200])
        else:
            print(f"❌ Gemini FAILED {r.status_code}: {r.text[:200]}")
    except Exception as e:
        print("❌ Gemini FAILED:", e)

if __name__ == "__main__":
    print("🔍 Running environment checks...\n")
    test_imap()
    test_hubspot()
    test_gemini()